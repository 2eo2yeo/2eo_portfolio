// tailwind 타입 정의

declare module '@tailwindcss/vite';