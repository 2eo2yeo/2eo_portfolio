import React from 'react';

const Copyright: React.FC = () => {
 return (
           <div className='-rotate-90 fixed bottom-20 right-0 w-30 h-16 z-30'>
                <p>Copyright @2eo</p>
           </div>
        );
}


export default Copyright
