import React, { useState, useEffect } from "react";
import axios from "axios";
import IntroduceCardList from "../components/about/IntroduceCardList";

interface IntroduceItem {
  summary: string;
  long: string;
  icon: string;
}

const transition = { duration: 1.5 };

const About: React.FC = () => {
  const [openIndex, setOpenIndex] = useState<number | null>(null);
  const [introduce, setIntroduce] = useState<IntroduceItem[]>([]);

  useEffect(() => {
    axios("/data/introduce.json")
      .then((res) => setIntroduce(res.data))
      .catch((error) => console.log(error));
  }, []);

  const handleToggle = (index: number) => {
    setOpenIndex((prev) => (prev === index ? null : index));
  };

  return (
    <div className="flex flex-col justify-center gap-5 text-white">
      <IntroduceCardList
        items={introduce}
        openIndex={openIndex}
        onToggle={handleToggle}
        transition={transition}
      />
      <p>email copy</p>
    </div>
  );
};

export default About;
